import time
import xbmc
import os
import xbmcgui
import urllib2
import webbrowser

def menu():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
        function2,
        function3,
        function4,
        function5
        ) 
    call = dialog.select( "[B][COLOR magenta]Klepto Pairing Tool[/COLOR][/B]" , [ 
    "[B][COLOR cyan]Select the site to pair with:\r\n[/COLOR][/B]" ,
    "[B][COLOR magenta]      openload[/COLOR][/B]" ,
    "[B][COLOR magenta]      THE VIDEO ME[/COLOR][/B]" ,
    "[B][COLOR magenta]      VidUP me[/COLOR][/B]" ,
    "[B][COLOR magenta]      VIDEOSHARE[/COLOR][/B]" ] )
    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

os = platform()

def function1(): 0

def function2():
    site = 'https://olpair.com/'
    if os == 'android': 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % (site) )
    if os == 'osx':
        os.system("open -a /Applications/Safari.app %s") % (site)
    else:
        opensite = webbrowser.open(site)

def function3():
    site = 'https://thevideo.me/pair'
    if os == 'android': 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % (site) )
    if os == 'osx':
        os.system("open -a /Applications/Safari.app %s") % (site)
    else:
        opensite = webbrowser.open(site)
        
def function4():
    site = 'https://vidup.me/pair'
    if os == 'android': 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % (site) )
    if os == 'osx':
       os.system("open -a /Applications/Safari.app %s") % (site)
    else:
        opensite = webbrowser.open(site)
		
def function5():
    site = 'http://vshare.eu/pair'
    if os == 'android': 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % (site) )
    if os == 'osx':
        os.system("open -a /Applications/Safari.app %s") % (site)
    else:
        opensite = webbrowser.open(site)
		
menu()
