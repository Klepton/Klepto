import os, xbmc, xbmcaddon
import binascii

#########################################################
### User Edit Variables #################################
#########################################################
# Enable/Disable text file caching with 'Yes' or 'No'
# Age is how often it is checked (in minutes)
CACHETEXT      = binascii.unhexlify('596573')
CACHEAGE       = 30

ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = binascii.unhexlify('4b6c6570746f2057697a617264')
BUILDERNAME    = binascii.unhexlify('4b6c6570746f')
EXCLUDES       = [ADDON_ID]
# Text File with build info in it
BUILDFILE      = binascii.unhexlify('68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f4b6c6570746f6e2f57697a6172642f6d61737465722f4b6c6570746f2e747874')
# How often you would like it to check for build updates (in days)
# 0 being every startup of Kodi
UPDATECHECK    = 0
# Text File with APK info in it.
APKFILE        = binascii.unhexlify('68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f4b6c6570746f6e2f57697a6172642f6d61737465722f4b6c6570746f41706b732e747874')
# Text File with YouTube Videos URLs.  Leave as 'http://' to ignore
YOUTUBETITLE   = binascii.unhexlify('526576696577732026205475746f7269616c73')
YOUTUBEFILE    = binascii.unhexlify('687474703a2f2f')
# Text File for Addon Installer.  Leave as 'http://' to ignore
ADDONFILE      = binascii.unhexlify('687474703a2f2f')
# Text File for Advanced Settings.  Leave as 'http://' to ignore
ADVANCEDFILE   = binascii.unhexlify('687474703a2f2f')

# Don't need to edit; used for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons then place them in the Resources/Art/
# folder of the Wizard then use os.path.join(ART, 'imagename.png')
# Do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'maint.png')
#           ICONSETTINGS  = 'http://yourHost/images/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = os.path.join(ART, 'Builds.png')
ICONWARNING    = os.path.join(ART, 'Warning.png')
ICONMAINT      = os.path.join(ART, 'Maintenance.png')
ICONCLEANUP    = os.path.join(ART, 'Cleanup.png')
ICONCLEAR      = os.path.join(ART, 'Clear.png')
ICONMISC       = os.path.join(ART, 'Misc.png')
ICONKEYBOARD   = os.path.join(ART, 'Keyboard.png')
ICONVIEW       = os.path.join(ART, 'View.png')
ICONBACKRES    = os.path.join(ART, 'Restore3.png')
ICONBACKUP     = os.path.join(ART, 'Backup.png')
ICONRESTORE    = os.path.join(ART, 'Restore.png')
ICONTWEAKS     = os.path.join(ART, 'Tweaks.png')
ICONWIZARD     = os.path.join(ART, 'Wizard.png')
ICONFREQUENCY  = os.path.join(ART, 'Frequency.png')
ICONCACHE      = os.path.join(ART, 'Cache.png')
ICONPACKAGES   = os.path.join(ART, 'Packages.png')
ICONTHUMBS     = os.path.join(ART, 'Thumbs.png')
ICONLOGS       = os.path.join(ART, 'Logs.png')
ICONDATABASE   = os.path.join(ART, 'Databases.png')
ICONFRESH      = os.path.join(ART, 'Fresh.png')
ICONVIDEO      = os.path.join(ART, 'Video.png')
ICONNETWORK    = os.path.join(ART, 'Network.png')
ICONSPEED      = os.path.join(ART, 'SpeedTest.png')
ICONIP         = os.path.join(ART, 'IP.png')
ICONAPK        = os.path.join(ART, 'APK.png')
ICONKODI       = os.path.join(ART, 'Kodi.png')
ICONSPMC       = os.path.join(ART, 'SPMC.png')
ICONADDONS     = os.path.join(ART, 'Addons.png')
ICONYOUTUBE    = os.path.join(ART, 'YouTube.png')
ICONSAVE       = os.path.join(ART, 'Save.png')
ICONTRAKT      = os.path.join(ART, 'Trakt.png')
ICONALLUC      = os.path.join(ART, 'Alluc.png')
ICONREAL       = os.path.join(ART, 'RealDebrid.png')
ICONLOGIN      = os.path.join(ART, 'Login.png')
ICONFAVS       = os.path.join(ART, 'Favorites.png')
ICONIMPORT     = os.path.join(ART, 'Import.png')
ICONEXPORT     = os.path.join(ART, 'Export.png')
ICONSOURCES    = os.path.join(ART, 'Sources.png')
ICONPROFILES   = os.path.join(ART, 'Profiles.png')
ICONCLOSE      = os.path.join(ART, 'Close.png')
ICONUPLOAD     = os.path.join(ART, 'Upload.png')
ICONADVANCED   = os.path.join(ART, 'Advanced.png')
ICONSUPER      = os.path.join(ART, 'Super.png')
ICONREPOS      = os.path.join(ART, 'Repository.png')
ICONLIST       = os.path.join(ART, 'List.png')
ICONREMOVE     = os.path.join(ART, 'Remove.png')
ICONEDIT       = os.path.join(ART, 'Edit.png')
ICONTRASH      = os.path.join(ART, 'Trash.png')
ICONQR         = os.path.join(ART, 'QR.png')
ICONNOTIFY     = os.path.join(ART, 'Notifications.png')
ICONUPDATE     = os.path.join(ART, 'Update.png')
ICONFIRST      = os.path.join(ART, 'Run.png')
ICONRUN        = os.path.join(ART, 'Run2.png')
ICONCONTACT    = os.path.join(ART, 'Support.png')
ICONSETTINGS   = os.path.join(ART, 'Settings.png')
ICONDEVELOP    = os.path.join(ART, 'Developer.png')
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = binascii.unhexlify('4e6f')
# Character used in seperator
SPACER         = binascii.unhexlify('2a2d')

# You can edit these however you want, just make sure that you have
# a %s in each of the THEMEs so it grabs the text from the menu item
COLOR1         = binascii.unhexlify('6d6167656e7461')
COLOR2         = binascii.unhexlify('6379616e')
# Primary Menu Items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+'][I][B]([COLOR '+COLOR2+']Klepto[/COLOR])[/B][/I][/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Alternate Items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Chosen Build Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Chosen Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME6         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'

# Message for Contact Page
# Enable 'Contact' menu item; 'Yes' hide or 'No' don't hide
HIDECONTACT    = binascii.unhexlify('4e6f')
# You can add \n to do line breaks
CONTACT        = '[B][COLOR '+COLOR2+']Thank you for choosing the [COLOR '+COLOR1+']Klepto[/COLOR] Wizard!\r\n\r\nFor Builds and Wizard support, contact me on Twitter at:  [COLOR '+COLOR1+']@K1ept0[/COLOR][/B]\n\n*** Note - Twitter handle uses "one" and "zero" in name!'
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = binascii.unhexlify('687474703a2f2f')
CONTACTFANART  = binascii.unhexlify('687474703a2f2f')
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = binascii.unhexlify('4e6f')
# URL to wizard version
WIZARDFILE     = binascii.unhexlify('68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f4b6c6570746f6e2f57697a6172642f6d61737465722f4b6c6570746f2e747874')
#########################################################

#########################################################
### AUTO INSTALL REPO ###################################
############### IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = binascii.unhexlify('4e6f')
# Addon ID for the repository
REPOID         = ''
# URL to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = binascii.unhexlify('687474703a2f2f')
# URL to folder zip is located in
REPOZIPURL     = binascii.unhexlify('687474703a2f2f')
#########################################################

#########################################################
### NOTIFICATION WINDOW #################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = binascii.unhexlify('4e6f')
# URL to notification file
NOTIFICATION   = binascii.unhexlify('687474703a2f2f')
# Use either 'Text' or 'Image'
HEADERTYPE     = binascii.unhexlify('54657874')
HEADERMESSAGE  = binascii.unhexlify('5b425d4b6c6570746f2057697a6172645b2f425d')
# URL to image if using Image 424x180
HEADERIMAGE    = binascii.unhexlify('687474703a2f2f')
# Background for Notification Window
BACKGROUND     = ''
#########################################################