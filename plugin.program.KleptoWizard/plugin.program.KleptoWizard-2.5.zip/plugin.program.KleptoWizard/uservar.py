import os, xbmc, xbmcaddon
import binascii

#########################################################
### User Edit Variables #################################
#########################################################
# Enable/Disable text file caching with 'Yes' or 'No'
# Age is how often it is checked (in minutes)
CACHETEXT      = binascii.unhexlify('596573')
CACHEAGE       = 30

ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = binascii.unhexlify('4b6c6570746f2057697a617264')
BUILDERNAME    = binascii.unhexlify('4b6c6570746f')
EXCLUDES       = [ADDON_ID]
# Text File with build info in it
BUILDFILE      = binascii.unhexlify('68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f4b6c6570746f6e2f57697a6172642f6d61737465722f4b6c6570746f2e747874')
# How often you would like it to check for build updates (in days)
# 0 being every startup of Kodi
UPDATECHECK    = 0
# Text File with APK info in it.
APKFILE        = binascii.unhexlify('68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f4b6c6570746f6e2f57697a6172642f6d61737465722f4b6c6570746f41706b732e747874')
# Text File with YouTube Videos URLs.  Leave as 'http://' to ignore
YOUTUBETITLE   = binascii.unhexlify('526576696577732026205475746f7269616c73')
YOUTUBEFILE    = binascii.unhexlify('687474703a2f2f')
# Text File for Addon Installer.  Leave as 'http://' to ignore
ADDONFILE      = binascii.unhexlify('687474703a2f2f')
# Text File for Advanced Settings.  Leave as 'http://' to ignore
ADVANCEDFILE   = binascii.unhexlify('687474703a2f2f')

# Don't need to edit; used for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons then place them in the Resources/Art/
# folder of the Wizard then use os.path.join(ART, 'imagename.png')
# Do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'maint.png')
#           ICONSETTINGS  = 'http://yourHost/images/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = binascii.unhexlify('687474703a2f2f')
ICONMAINT      = binascii.unhexlify('687474703a2f2f')
ICONAPK        = binascii.unhexlify('687474703a2f2f')
ICONADDONS     = binascii.unhexlify('687474703a2f2f')
ICONYOUTUBE    = binascii.unhexlify('687474703a2f2f')
ICONSAVE       = binascii.unhexlify('687474703a2f2f')
ICONTRAKT      = binascii.unhexlify('687474703a2f2f')
ICONALLUC      = binascii.unhexlify('687474703a2f2f')
ICONREAL       = binascii.unhexlify('687474703a2f2f')
ICONLOGIN      = binascii.unhexlify('687474703a2f2f')
ICONFAVS       = binascii.unhexlify('687474703a2f2f')
ICONCONTACT    = binascii.unhexlify('687474703a2f2f')
ICONSETTINGS   = binascii.unhexlify('687474703a2f2f')
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = binascii.unhexlify('4e6f')
# Character used in seperator
SPACER         = binascii.unhexlify('2a2d')

# You can edit these however you want, just make sure that you have
# a %s in each of the THEMEs so it grabs the text from the menu item
COLOR1         = binascii.unhexlify('6d6167656e7461')
COLOR2         = binascii.unhexlify('6379616e')
# Primary Menu Items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+'][I][B]([COLOR '+COLOR2+']Klepto[/COLOR])[/B][/I][/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Alternate Items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Chosen Build Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Chosen Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME6         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'

# Message for Contact Page
# Enable 'Contact' menu item; 'Yes' hide or 'No' don't hide
HIDECONTACT    = 'No'
# You can add \n to do line breaks
CONTACT        = '[B][COLOR '+COLOR2+']Thank you for choosing the [COLOR '+COLOR1+']Klepto[/COLOR] Wizard!\r\n\r\nFor Builds and Wizard support, contact me on Twitter at:  [COLOR '+COLOR1+']@K1ept0[/COLOR][/B]\n\n*** Note - Twitter handle uses "one" and "zero" in name!'
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = binascii.unhexlify('687474703a2f2f')
CONTACTFANART  = ''
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = binascii.unhexlify('4e6f')
# URL to wizard version
WIZARDFILE     = binascii.unhexlify('68747470733a2f2f7261772e67697468756275736572636f6e74656e742e636f6d2f4b6c6570746f6e2f57697a6172642f6d61737465722f4b6c6570746f2e747874')
#########################################################

#########################################################
### AUTO INSTALL REPO ###################################
############### IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = binascii.unhexlify('4e6f')
# Addon ID for the repository
REPOID         = ''
# URL to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = ''
# URL to folder zip is located in
REPOZIPURL     = ''
#########################################################

#########################################################
### NOTIFICATION WINDOW #################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = binascii.unhexlify('4e6f')
# URL to notification file
NOTIFICATION   = ''
# Use either 'Text' or 'Image'
HEADERTYPE     = binascii.unhexlify('54657874')
HEADERMESSAGE  = binascii.unhexlify('5b425d4b6c6570746f2057697a6172645b2f425d')
# URL to image if using Image 424x180
HEADERIMAGE    = ''
# Background for Notification Window
BACKGROUND     = ''
#########################################################