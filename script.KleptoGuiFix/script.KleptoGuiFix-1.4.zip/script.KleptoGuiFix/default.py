import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import time


xbmcaddon.Addon(id='script.KleptoGuiFix').openSettings()
xbmcaddon.Addon(id='script.KleptoGuiFix').getSetting('select_skin')
